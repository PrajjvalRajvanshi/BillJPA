package com.cg.billing.client;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingServicesImpl;

public class TestMain {
	static BillingServicesImpl services = new BillingServicesImpl();

	public static void main(String[] args)
	{
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
        services.createPlanDetails();
        services.acceptCustomerDetails("Prajjval", "Rajvanshi", "prince@gmail.com", "14Nov19971", "Muzaffarnagar", "U.P.", 251001, "Muzaffarnagar", "U.P.", 251001);
       System.out.println( services.getPlanAllDetails());
       try {
		System.out.println(services.openPostpaidMobileAccount(1, 501));
		System.out.println("****************************************************************************");
		System.out.println(services.generateMonthlyMobileBill(1, 2, "January", 100, 50, 400, 50, 5000));
		System.out.println("****************************************************************************");
		System.out.println("Get Customer Detail");
		System.out.println(services.getCustomerDetails(1));
		System.out.println("****************************************************************************");
		System.out.println("All Customer Details");
		System.out.println(services.getAllCustomerDetails());
		System.out.println("****************************************************************************");
		System.out.println("PostPaid Account Details");
		System.out.println(services.getPostPaidAccountDetails(1, 2));
		System.out.println("****************************************************************************");
		System.out.println("customer All Postpaid Account Details");
		System.out.println(services.getCustomerAllPostpaidAccountsDetails(1));
		System.out.println("****************************************************************************");
		System.out.println("Mobile Bill Details--");
		System.out.println(services.getMobileBillDetails(1, 2,"January"));
		System.out.println("******************************************************************************");
		System.out.println("Customer Post Paid Account All bills");
		System.out.println(services.getCustomerPostPaidAccountAllBillDetails(1, 2));
		System.out.println("*****************************************************************************");
		System.out.println("Change Plan");
		System.out.println(services.changePlan(1, 2, 502));
		System.out.println("*/*******************************************************");
		System.out.println("Close PostPaid Account");
		System.out.println(services.closeCustomerPostPaidAccount(1, 2));
		System.out.println("*/********************************************************");
		System.out.println(services.removeCustomerDetails(1));
		System.out.println("Account Removed");
	} catch (PlanDetailsNotFoundException | CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | InvalidBillMonthException | BillDetailsNotFoundException e) {
		System.out.println(e.getMessage());
	}
	}

}
