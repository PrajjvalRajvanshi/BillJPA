package com.cg.billing.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

@Entity
public class Plan
{
	@Id
    private int planId;
    private int monthlyRental,freeLocalCalls,freeStdCalls,freeLocalSMS,freeStdSMS,freeInternetUsageUnits;
    private float localCallRate,stdCallRate,locaSMSRate,stdSMSRate,internetDataUsageRate;
    private String planCircle,planName;
    
    @OneToMany(mappedBy="plan",cascade=CascadeType.ALL,orphanRemoval=true)// cascade=CascadeType.ALL)
    @MapKey
    private Map<Long,PostpaidAccount> accounts;
    
    public Plan()
    {
    	
    }

    
	public Plan(int planId, int monthlyRental, int freeLocalCalls, int freeStdCalls, int freeLocalSMS, int freeStdSMS,
			int freeInternetUsageUnits, float localCallRate, float stdCallRate, float locaSMSRate, float stdSMSRate,
			float internetDataUsageRate, String planCircle, String planName) {
		super();
		this.planId = planId;
		this.monthlyRental = monthlyRental;
		this.freeLocalCalls = freeLocalCalls;
		this.freeStdCalls = freeStdCalls;
		this.freeLocalSMS = freeLocalSMS;
		this.freeStdSMS = freeStdSMS;
		this.freeInternetUsageUnits = freeInternetUsageUnits;
		this.localCallRate = localCallRate;
		this.stdCallRate = stdCallRate;
		this.locaSMSRate = locaSMSRate;
		this.stdSMSRate = stdSMSRate;
		this.internetDataUsageRate = internetDataUsageRate;
		this.planCircle = planCircle;
		this.planName = planName;
	}


	public Plan(int planId, int monthlyRental, int freeLocalCalls, int freeStdCalls, int freeLocalSMS, int freeStdSMS,
			int freeInternetUsageUnits, float localCallRate, float stdCallRate, float locaSMSRate, float stdSMSRate,
			float internetDataUsageRate, String planCircle, String planName, Map<Long, PostpaidAccount> accounts) {
		super();
		this.planId = planId;
		this.monthlyRental = monthlyRental;
		this.freeLocalCalls = freeLocalCalls;
		this.freeStdCalls = freeStdCalls;
		this.freeLocalSMS = freeLocalSMS;
		this.freeStdSMS = freeStdSMS;
		this.freeInternetUsageUnits = freeInternetUsageUnits;
		this.localCallRate = localCallRate;
		this.stdCallRate = stdCallRate;
		this.locaSMSRate = locaSMSRate;
		this.stdSMSRate = stdSMSRate;
		this.internetDataUsageRate = internetDataUsageRate;
		this.planCircle = planCircle;
		this.planName = planName;
		this.accounts = accounts;
	}

	

	public int getPlanId() {
		return planId;
	}

	public void setPlanId(int planId) {
		this.planId = planId;
	}

	public int getMonthlyRental() {
		return monthlyRental;
	}

	public void setMonthlyRental(int monthlyRental) {
		this.monthlyRental = monthlyRental;
	}

	public int getFreeLocalCalls() {
		return freeLocalCalls;
	}

	public void setFreeLocalCalls(int freeLocalCalls) {
		this.freeLocalCalls = freeLocalCalls;
	}

	public int getFreeStdCalls() {
		return freeStdCalls;
	}

	public void setFreeStdCalls(int freeStdCalls) {
		this.freeStdCalls = freeStdCalls;
	}

	public int getFreeLocalSMS() {
		return freeLocalSMS;
	}

	public void setFreeLocalSMS(int freeLocalSMS) {
		this.freeLocalSMS = freeLocalSMS;
	}

	public int getFreeStdSMS() {
		return freeStdSMS;
	}

	public void setFreeStdSMS(int freeStdSMS) {
		this.freeStdSMS = freeStdSMS;
	}

	public int getFreeInternetUsageUnits() {
		return freeInternetUsageUnits;
	}

	public void setFreeInternetUsageUnits(int freeInternetUsageUnits) {
		this.freeInternetUsageUnits = freeInternetUsageUnits;
	}

	public float getLocalCallRate() {
		return localCallRate;
	}

	public void setLocalCallRate(float localCallRate) {
		this.localCallRate = localCallRate;
	}

	public float getStdCallRate() {
		return stdCallRate;
	}

	public void setStdCallRate(float stdCallRate) {
		this.stdCallRate = stdCallRate;
	}

	public float getLocaSMSRate() {
		return locaSMSRate;
	}

	public void setLocaSMSRate(float locaSMSRate) {
		this.locaSMSRate = locaSMSRate;
	}

	public float getStdSMSRate() {
		return stdSMSRate;
	}

	public void setStdSMSRate(float stdSMSRate) {
		this.stdSMSRate = stdSMSRate;
	}

	public float getInternetDataUsageRate() {
		return internetDataUsageRate;
	}

	public void setInternetDataUsageRate(float internetDataUsageRate) {
		this.internetDataUsageRate = internetDataUsageRate;
	}

	public String getPlanCircle() {
		return planCircle;
	}

	public void setPlanCircle(String planCircle) {
		this.planCircle = planCircle;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public Map<Long, PostpaidAccount> getAccounts() {
		return accounts;
	}

	public void setAccounts(Map<Long, PostpaidAccount> accounts) {
		this.accounts = accounts;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accounts == null) ? 0 : accounts.hashCode());
		result = prime * result + freeInternetUsageUnits;
		result = prime * result + freeLocalCalls;
		result = prime * result + freeLocalSMS;
		result = prime * result + freeStdCalls;
		result = prime * result + freeStdSMS;
		result = prime * result + Float.floatToIntBits(internetDataUsageRate);
		result = prime * result + Float.floatToIntBits(locaSMSRate);
		result = prime * result + Float.floatToIntBits(localCallRate);
		result = prime * result + monthlyRental;
		result = prime * result + ((planCircle == null) ? 0 : planCircle.hashCode());
		result = prime * result + planId;
		result = prime * result + ((planName == null) ? 0 : planName.hashCode());
		result = prime * result + Float.floatToIntBits(stdCallRate);
		result = prime * result + Float.floatToIntBits(stdSMSRate);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Plan other = (Plan) obj;
		if (accounts == null) {
			if (other.accounts != null)
				return false;
		} else if (!accounts.equals(other.accounts))
			return false;
		if (freeInternetUsageUnits != other.freeInternetUsageUnits)
			return false;
		if (freeLocalCalls != other.freeLocalCalls)
			return false;
		if (freeLocalSMS != other.freeLocalSMS)
			return false;
		if (freeStdCalls != other.freeStdCalls)
			return false;
		if (freeStdSMS != other.freeStdSMS)
			return false;
		if (Float.floatToIntBits(internetDataUsageRate) != Float.floatToIntBits(other.internetDataUsageRate))
			return false;
		if (Float.floatToIntBits(locaSMSRate) != Float.floatToIntBits(other.locaSMSRate))
			return false;
		if (Float.floatToIntBits(localCallRate) != Float.floatToIntBits(other.localCallRate))
			return false;
		if (monthlyRental != other.monthlyRental)
			return false;
		if (planCircle == null) {
			if (other.planCircle != null)
				return false;
		} else if (!planCircle.equals(other.planCircle))
			return false;
		if (planId != other.planId)
			return false;
		if (planName == null) {
			if (other.planName != null)
				return false;
		} else if (!planName.equals(other.planName))
			return false;
		if (Float.floatToIntBits(stdCallRate) != Float.floatToIntBits(other.stdCallRate))
			return false;
		if (Float.floatToIntBits(stdSMSRate) != Float.floatToIntBits(other.stdSMSRate))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Plan [planId=" + planId + ", monthlyRental=" + monthlyRental + ", freeLocalCalls=" + freeLocalCalls
				+ ", freeStdCalls=" + freeStdCalls + ", freeLocalSMS=" + freeLocalSMS + ", freeStdSMS=" + freeStdSMS
				+ ", freeInternetUsageUnits=" + freeInternetUsageUnits + ", localCallRate=" + localCallRate
				+ ", stdCallRate=" + stdCallRate + ", locaSMSRate=" + locaSMSRate + ", stdSMSRate=" + stdSMSRate
				+ ", internetDataUsageRate=" + internetDataUsageRate + ", planCircle=" + planCircle + ", planName="
				+ planName + ", accounts=" + accounts + "]";
	}
    
}
